document.getElementById("employeeForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Get values from inputs
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let designation = document.getElementById("designation").value;
    let department = document.getElementById("department").value;
    let phone = document.getElementById("phone").value;

    // Create object for employee data
    let employee = { name, email, designation, department, phone };

    // Retrieve existing data from Local Storage
    let employees = JSON.parse(localStorage.getItem("employees")) || [];
    
    // Retrieve existing data from Session Storage
    let sessionEmployees = JSON.parse(sessionStorage.getItem("employees")) || [];

    // Append new employee data to both storage arrays
    employees.push(employee);
    sessionEmployees.push(employee);

    // Store updated data in Local Storage
    localStorage.setItem("employees", JSON.stringify(employees));

    // Store updated data in Session Storage
    sessionStorage.setItem("employees", JSON.stringify(sessionEmployees));

    alert("Data saved to both Local and Session Storage!");
    // Clear the form
    document.getElementById("employeeForm").reset();
});


// function displayEmployees() {
//     let employees = JSON.parse(localStorage.getItem("employees")) || [];
//     let tableBody = document.getElementById("employeeTable").querySelector("tbody");
//     tableBody.innerHTML = ""; // Clear previous content

//     employees.forEach(emp => {
//         let row = `<tr>
//             <td>${emp.name}</td>
//             <td>${emp.email}</td>
//             <td>${emp.designation}</td>
//             <td>${emp.department}</td>
//             <td>${emp.phone}</td>
//         </tr>`;
//         tableBody.innerHTML += row;
//     });
    
// document.getElementById("employeeCount").textContent = `Total Employees: ${employees.length}`;
// }

// function refreshLocalStorage() {
//     localStorage.removeItem("employees"); // Clears the stored employees data
//     displayEmployees(); 
// }



// Load stored data when page loads
// document.addEventListener("DOMContentLoaded", displayEmployees);